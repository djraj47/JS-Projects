function searcitem() {
    var input = document.getElementById("menusearch").value.toLowerCase();
    var boxes = document.querySelectorAll(".items");

    for (var i = 0; i < boxes.length; i++) {
        var titleElement = boxes[i].getElementsByClassName("item-detail")[0];
        if (titleElement) {
            var title = titleElement.getElementsByClassName("item-title")[0].innerText.toLowerCase();
            if (title.indexOf(input) > -1) {
                boxes[i].style.display = "";
            } else {
                boxes[i].style.display = "none";
            }
        }
    }
}

// ===========================================================================================

function showDiv(selectedDiv) {
    let menu = document.querySelector(".menu");
    let reviews = document.querySelector(".reviews");
    let photos = document.querySelector(".photos");


    const divMap = {
        'menu': menu,
        'photos': photos,
        'reviews': reviews
    };

    // Hide all divs
    for (const div of Object.values(divMap)) {
        div.classList.remove('active1');
        div.classList.add('hidden');
    }

    // Show the selected div
    divMap[selectedDiv].classList.remove('hidden');
    divMap[selectedDiv].classList.add('active1');
}

// =================================================================================

function setActiveDiv(divId) {
    // Get all the div elements with the class "order-items"
    var divs = document.querySelectorAll('.order-items div');

    // Loop through all the div elements
    for (var i = 0; i < divs.length; i++) {
        // Remove the "active" class from all div elements
        divs[i].classList.remove('active');
    }

    // Set the clicked div as "active"
    var targetDiv = document.getElementById(divId);
    if (targetDiv) {
        targetDiv.classList.add('active');
    }
}

function bothfunction(div) {
    showDiv(div);
    setActiveDiv(div);

}

// =================================================================================
// Get all the list items with the class "menu-nav"
var lis = document.querySelectorAll('.menu-nav li');

// Define a function to handle the click event
function selectmenu(event) {
    // Loop through all list items
    for (var i = 0; i < lis.length; i++) {
        // Remove the "active-menu" class from all list items
        lis[i].classList.remove('active-menu');
    }

    // Set the clicked list item as "active-menu"
    event.target.classList.add('active-menu');
}

// Add the click event listener to each list item
for (var i = 0; i < lis.length; i++) {
    lis[i].addEventListener('click', selectmenu);
}




document.addEventListener("DOMContentLoaded", function () {
    const menuItems = document.querySelectorAll(".menu-nav ul li");
    const itemCategories = document.querySelectorAll(".items .category");

    // Add click event listeners to menu items
    menuItems.forEach((menuItem, index) => {
        menuItem.addEventListener("click", () => {
            // Hide all items
            itemCategories.forEach((category) => {
                category.style.display = "none";
            });

            // Show items with the same category as the clicked menu item
            const selectedCategory = menuItems[index].textContent;
            itemCategories.forEach((category, categoryIndex) => {
                if (category.textContent === selectedCategory) {
                    // Display the items in this category
                    category.parentElement.style.display = "block";
                }
            });
        });
    });
});


